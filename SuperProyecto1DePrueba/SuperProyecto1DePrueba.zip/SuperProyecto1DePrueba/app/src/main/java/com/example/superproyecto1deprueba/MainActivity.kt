package com.example.superproyecto1deprueba

import android.content.Intent
import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley

import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_main.*

var id = ""
var text1= ""
var text2 = ""

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)

        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }

        buttonSendRequest.setOnClickListener {
            requestToServer();
        }
        productCheck.setOnClickListener {
            var intent = Intent(this, Product::class.java)
            if (textInput.getText().toString() != "" && (textInput.getText().toString() == "1" || textInput.getText().toString() == "2" || textInput.getText().toString() ==  "3" || textInput.getText().toString() == "4"
                        || textInput.getText().toString() ==  "5" || textInput.getText().toString() == "6" || textInput.getText().toString() == "7" || textInput.getText().toString() ==  "8"
                        || textInput.getText().toString() == "9") ) {
                id = textInput.getText().toString();
                requestToServer2()
                intent.putExtra("price",text2)
                startActivity(intent)
            }

        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    private fun requestToServer(){


        val queue = Volley.newRequestQueue(this)



        val url = "http://192.168.103.46:420/list"

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null,
            Response.Listener { response ->
                textView2.text = "List of products: %s".format(response.toString())
            },
            Response.ErrorListener { error ->
                // TODO: Handle error
            }
        )
        queue.add(jsonObjectRequest);
    }
    private fun requestToServer2(){


        val queue = Volley.newRequestQueue(this)



        val url = "http://192.168.103.46:420/product/"+id

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null,
            Response.Listener { response ->
                text1= response.get("product").toString()
                text2 = response.get("price").toString()
            },
            Response.ErrorListener { error ->
                // TODO: Handle error
            }
        )
        queue.add(jsonObjectRequest);
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}
